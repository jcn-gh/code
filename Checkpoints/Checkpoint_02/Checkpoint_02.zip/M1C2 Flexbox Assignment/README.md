# m1c2-flexbox-assignment
 this code serves as the starter code you will need to use for the module 1 checkpoint 2 flexbox assignment
